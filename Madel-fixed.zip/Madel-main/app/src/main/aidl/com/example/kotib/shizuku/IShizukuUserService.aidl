// Shizuku orqali root/adb (shell) imtiyozi bilan ishlaydigan alohida jarayon uchun AIDL interfeysi.
package com.example.kotib.shizuku;

interface IShizukuUserService {
    // Bitta shell buyrug'ini bajaradi va stdout+stderr matnini, exit kodini qaytaradi.
    // Format: birinchi qator "EXIT:<kod>", qolgani chiqish matni.
    String execCommand(String command, long timeoutMs);

    // Jarayonni to'xtatish (ilova tomonidan Shizuku ulanishini uzish uchun, ixtiyoriy).
    void destroy();
}
