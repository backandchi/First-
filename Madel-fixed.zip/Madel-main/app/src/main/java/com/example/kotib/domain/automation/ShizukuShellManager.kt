package com.example.kotib.domain.automation

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.example.kotib.shizuku.IShizukuUserService
import com.example.kotib.shizuku.ShizukuUserService
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

/**
 * Shizuku orqali (root yoki Android 11+ simsiz ADB debugging asosida) imtiyozli buyruqlarni
 * bajaradi. Oddiy root (su) bo'lmagan qurilmalarda ham ishlaydi, agar foydalanuvchida Shizuku
 * ilovasi o'rnatilgan va ishga tushirilgan bo'lsa.
 *
 * MUHIM (yiqilishning oldini olish): Shizuku.requestPermission()/checkSelfPermission() Shizuku
 * binder ulanmagan holatda chaqirilsa IllegalStateException otadi va butun ilovani yiqitadi.
 * Shu sabab bu klassdagi HAR BIR Shizuku chaqiruvi avval pingBinder() bilan tekshiriladi va
 * try/catch bilan o'raladi — Shizuku o'rnatilmagan yoki ishga tushmagan bo'lsa ham xavfsiz
 * `false` qaytaradi, ilova hech qachon yiqilmaydi.
 */
class ShizukuShellManager(private val context: Context) {

    companion object {
        private const val REQUEST_CODE = 20261002
    }

    @Volatile private var serviceBinder: IShizukuUserService? = null
    @Volatile private var pendingConnection: CompletableDeferred<IShizukuUserService?>? = null
    @Volatile private var pendingPermissionResult: CompletableDeferred<Boolean>? = null
    @Volatile private var listenerAttached = false

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE) {
            pendingPermissionResult?.let {
                if (!it.isCompleted) it.complete(grantResult == PackageManager.PERMISSION_GRANTED)
            }
        }
    }

    private fun ensureListenerAttached() {
        if (listenerAttached) return
        try {
            Shizuku.addRequestPermissionResultListener(permissionListener)
            listenerAttached = true
        } catch (_: Throwable) {
            // Shizuku kutubxonasi ishga tushmagan bo'lsa ham ilova davom etaversin
        }
    }

    /** Shizuku ilovasi o'rnatilgan va serveri (root yoki ADB orqali) ishga tushganmi. */
    fun isServiceRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) {
        false
    }

    /** Ruxsat allaqachon berilganmi. Shizuku ishlamasa — xavfsiz `false`. */
    fun hasPermission(): Boolean {
        if (!isServiceRunning()) return false
        return try {
            if (Shizuku.isPreV11()) {
                false // Juda eski Shizuku versiyasi — foydalanuvchidan yangilashni so'raymiz
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Ruxsat so'raydi va natijani (eng ko'p 60 soniya) kutadi.
     * Shizuku ishlamasa, juda eski versiya bo'lsa yoki xatolik yuz bersa — ilova yiqilmaydi,
     * shunchaki `false` qaytadi.
     */
    suspend fun requestPermission(): Boolean {
        ensureListenerAttached()
        if (!isServiceRunning()) return false
        if (hasPermission()) return true
        if (try { Shizuku.isPreV11() } catch (_: Throwable) { true }) return false

        val deferred = CompletableDeferred<Boolean>()
        pendingPermissionResult = deferred
        return try {
            Shizuku.requestPermission(REQUEST_CODE)
            withTimeoutOrNull(60_000L) { deferred.await() } ?: false
        } catch (_: Throwable) {
            false
        } finally {
            pendingPermissionResult = null
        }
    }

    private fun buildArgs() =
        Shizuku.UserServiceArgs(ComponentName(context.packageName, ShizukuUserService::class.java.name))
            .daemon(false)
            .processNameSuffix("shizuku_shell")
            .debuggable(false)
            .version(1)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            serviceBinder = if (binder != null && binder.pingBinder()) {
                IShizukuUserService.Stub.asInterface(binder)
            } else null
            pendingConnection?.complete(serviceBinder)
            pendingConnection = null
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBinder = null
        }
    }

    private suspend fun getOrBindService(): IShizukuUserService? {
        serviceBinder?.let { if (it.asBinder().pingBinder()) return it }
        if (!isServiceRunning() || !hasPermission()) return null

        val deferred = CompletableDeferred<IShizukuUserService?>()
        pendingConnection = deferred
        return try {
            Shizuku.bindUserService(buildArgs(), connection)
            withTimeoutOrNull(10_000L) { deferred.await() }
        } catch (_: Throwable) {
            pendingConnection = null
            null
        }
    }

    /** Shizuku orqali buyruq bajarish uchun tayyormi (ishga tushgan + ruxsat berilgan). */
    fun isAvailable(): Boolean = isServiceRunning() && hasPermission()

    suspend fun executeCommand(command: String, timeoutMs: Long = 12_000L): ShellResult = withContext(Dispatchers.IO) {
        val service = getOrBindService()
            ?: return@withContext ShellResult(-1, "", "Shizuku ulanmagan yoki ruxsat berilmagan", false)

        try {
            val raw = service.execCommand(command, timeoutMs)
            val firstLineEnd = raw.indexOf('\n')
            val firstLine = if (firstLineEnd >= 0) raw.substring(0, firstLineEnd) else raw
            val rest = (if (firstLineEnd >= 0) raw.substring(firstLineEnd + 1) else "").trim()
            val code = firstLine.removePrefix("EXIT:").trim().toIntOrNull() ?: -1
            ShellResult(code, rest, if (code != 0) rest else "", code == 0)
        } catch (e: Throwable) {
            serviceBinder = null
            ShellResult(-1, "", e.message ?: "Shizuku xizmati bilan aloqa uzildi", false)
        }
    }

    /** Ilova yopilganda chaqiring (ixtiyoriy tozalash). */
    fun release() {
        try {
            Shizuku.unbindUserService(buildArgs(), connection, true)
        } catch (_: Throwable) {
        }
        try {
            if (listenerAttached) Shizuku.removeRequestPermissionResultListener(permissionListener)
        } catch (_: Throwable) {
        }
    }
}
