package com.example.kotib.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.KotibApp
import kotlinx.coroutines.launch

/** Rejalashtirilgan vazifa signali kelganda agentni ishga tushiradi. */
class KotibTaskReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return
        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        if (taskId < 0) return
        val app = context.applicationContext as? KotibApp ?: return
        val container = app.container

        val pending = goAsync()
        container.applicationScope.launch {
            try {
                container.automationScheduler.runTask(taskId, container.agentEngine)
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val EXTRA_TASK_ID = "kotib_task_id"
    }
}
