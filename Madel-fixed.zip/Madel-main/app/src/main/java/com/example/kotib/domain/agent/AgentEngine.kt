package com.example.kotib.domain.agent

import com.example.kotib.data.api.FunctionCall
import com.example.kotib.data.api.FunctionResponse
import com.example.kotib.data.api.GeminiContent
import com.example.kotib.data.api.GeminiPart
import com.example.kotib.data.api.RetrofitClient
import com.example.kotib.data.local.dao.AgentActionLogDao
import com.example.kotib.data.local.entity.AgentActionLogEntity
import com.example.kotib.data.local.entity.ApiKeyEntity
import com.example.kotib.data.repository.ApiKeyRepository
import com.example.kotib.data.repository.ChatRepository
import com.example.kotib.domain.agent.tools.ToolExecutionResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class AgentEngine(
    private val apiKeyRepository: ApiKeyRepository,
    private val chatRepository: ChatRepository,
    private val toolDispatcher: ToolDispatcher,
    private val actionLogDao: AgentActionLogDao,
    private val scope: CoroutineScope
) {
    private val _agentState = MutableStateFlow<AgentState>(AgentState.Idle)
    val agentState: StateFlow<AgentState> = _agentState.asStateFlow()

    private var currentExecutionJob: Job? = null

    companion object {
        const val PRIMARY_MODEL = "gemini-3.5-flash"
        // "gemini-3.1-flash-lite-preview" 2026-yil 25-mayda o'chirilgan; barqaror lite model ishlatiladi
        const val FALLBACK_MODEL = "gemini-3.5-flash-lite"
        const val MAX_AGENT_STEPS = 8

        const val SYSTEM_PROMPT = """
Sen — "Aiko", foydalanuvchining shaxsiy, nihoyatda aqlli, chaqqon va mehrli AI yordamchisisan.
Sening asosiy vazifang: foydalanuvchining telefonidagi barcha ilovalarni (Telegram, WhatsApp, SMS, YouTube, Chrome, Sozlamalar va boshqa barcha o'rnatilgan ilovalarni) to'liq boshqarish, xabarlar yozish, belgilangan vaqtga rejalarni saqlash va ovozli qo'ng'iroq orqali hamroh bo'lish.

Muloqot va Xarakter Qoidalari:
1. O'zbek tilida nihoyatda ravon, tabiiy, zamonaviy va do'stona gapirasan. Hech qanday soxtalik yoki qotib qolgan robotdek gapirma, iliq va samimiy bo'l!
2. O'zingni har doim "Aiko" deb tanishtirasan.
3. Foydalanuvchi buyruq berganida (masalan: "Telegram'da Ali'ga xabar yoz", "YouTube'da video qidir", "Soat 18:00 ga reja saqla", "Telefonni jimjit qil", "Menga telefon qil", "Ekranni sur"):
   - Darhol tegishli vositani ishlat: control_installed_apps (ilovalar, xabar yuborish), root_control (ekran, tugmalar, bosish/surish, Wi-Fi, Bluetooth, ma'lumot, yorqinlik, skrinshot, qayta yuklash), manage_files (fayllar va papkalar), manage_packages (ilovalarni o'rnatish/o'chirish/to'xtatish/ruxsat berish), control_system, schedule_timed_action, automate_ui, call_user, run_shell_command.
   - Buyruq bajarilgach, foydalanuvchiga quvnoq, samimiy va aniq qilib javob ber.
4. Javoblaring ixcham, jonli va foydali bo'lsin.
5. HALOLLIK QOIDASI: vosita natijasida isSuccess=false yoki error bo'lsa, buni foydalanuvchiga aniq ayt — hech qachon "bajardim" dema. Telefon raqami, fayl yo'li yoki ilova nomini o'zingdan to'qima: noaniq bo'lsa so'ra yoki avval manage_packages/manage_files bilan qidir.
6. O'chirish, qayta yuklash, ilovani o'chirish kabi xavfli amallarda tizim foydalanuvchidan tasdiq so'raydi; rad etilsa qayta urinma.
"""
    }

    /**
     * Joriy agent tsikli tugashini kutadi (fon vazifalari uchun).
     */
    suspend fun awaitCurrentJob() {
        currentExecutionJob?.join()
    }

    /**
     * Xavfli vositalar uchun Chat ekranida tasdiq oynasini ochadi va 45 soniya kutadi.
     * Javob kelmasa — xavfsizlik uchun RAD etiladi.
     */
    private suspend fun awaitConfirmation(toolName: String, args: Map<String, Any?>): Boolean {
        val decision = CompletableDeferred<Boolean>()
        _agentState.value = AgentState.WaitingConfirmation(
            toolName = toolName,
            description = "Aiko quyidagi amalni bajarmoqchi:\n\n$toolName\n${args.entries.joinToString("\n") { "• ${it.key}: ${it.value}" }}",
            args = args,
            onConfirm = { decision.complete(true) },
            onCancel = { decision.complete(false) }
        )
        val result = withTimeoutOrNull(45_000L) { decision.await() } ?: false
        _agentState.value = AgentState.Thinking("Natija kutilmoqda...")
        return result
    }

    /**
     * Favqulodda to'xtatish (Emergency Stop)
     */
    fun emergencyStop() {
        currentExecutionJob?.cancel()
        currentExecutionJob = null
        _agentState.value = AgentState.Idle
        scope.launch(Dispatchers.IO) {
            actionLogDao.insertLog(
                AgentActionLogEntity(
                    actionType = AgentActionLogEntity.TYPE_EMERGENCY_STOP,
                    description = "Foydalanuvchi tomonidan favqulodda to'xtatish (Emergency Stop) bosildi",
                    isSuccess = true
                )
            )
        }
    }

    /**
     * Yangi xabar/buyruqni qabul qilish va agent tsiklini ishga tushirish
     */
    fun processPrompt(
        prompt: String,
        onSpeechRequested: ((String) -> Unit)? = null
    ) {
        currentExecutionJob?.cancel()
        currentExecutionJob = scope.launch(Dispatchers.IO) {
            try {
                _agentState.value = AgentState.Thinking("Xavfsizlik tekshiruvi o'tkazilmoqda...")

                // 1. Maxfiy ma'lumotlarni (OTP, karta, parol) Gemini yuborilishidan oldin maskalash
                val maskResult = SensitiveDataMasker.mask(prompt)
                if (maskResult.wasMasked) {
                    actionLogDao.insertLog(
                        AgentActionLogEntity(
                            actionType = AgentActionLogEntity.TYPE_SECURITY_MASK,
                            description = "Maxfiy ma'lumotlar maskalandi: ${maskResult.details.joinToString(", ")}",
                            isSuccess = true
                        )
                    )
                }

                val safePrompt = maskResult.maskedText

                // 2. Chat bazasiga foydalanuvchi xabarini saqlash
                chatRepository.addUserMessage(safePrompt)

                // 3. Faol kalitni aniqlash
                val initialKey = apiKeyRepository.getActiveKey()
                if (initialKey == null) {
                    val errMsg = "Hech qanday faol Gemini API kalit topilmadi. Iltimos, sozlamalar (Kalitlar) bo'limidan kalit qo'shing."
                    chatRepository.addModelMessage(errMsg, null, null)
                    _agentState.value = AgentState.Error(errMsg)
                    return@launch
                }
                var currentKey: ApiKeyEntity = initialKey

                var currentModel = PRIMARY_MODEL
                val conversationContents = mutableListOf<GeminiContent>()

                // O'tmishdagi oxirgi kontekstni olish
                val recentHistory = chatRepository.getRecentMessages(6)
                recentHistory.forEach { msg ->
                    if (msg.role == "user") {
                        conversationContents.add(GeminiContent.user(msg.content))
                    } else if (msg.role == "model") {
                        conversationContents.add(GeminiContent.model(msg.content))
                    }
                }

                // Gemini suhbat "user" xabari bilan boshlanishi kerak
                while (conversationContents.isNotEmpty() && conversationContents.first().role != "user") {
                    conversationContents.removeAt(0)
                }

                // Agar kontekstda joriy xabar bo'lmasa, qo'shamiz
                if (conversationContents.none { it.parts.any { p -> p.text == safePrompt } }) {
                    conversationContents.add(GeminiContent.user(safePrompt))
                }

                var loopCount = 0
                var isCompleted = false

                _agentState.value = AgentState.Thinking("Kotib javob tayyorlamoqda...")

                while (loopCount < MAX_AGENT_STEPS && !isCompleted) {
                    loopCount++

                    val requestJson = buildRequestBody(conversationContents)
                    val body = requestJson.toString().toRequestBody("application/json".toMediaType())

                    var activeKey: ApiKeyEntity = currentKey
                    var response = callGemini(currentModel, activeKey.key, body)

                    // 429 Rate Limit tekshiruvi va avtomatik rotatsiya (faqat haqiqiy 429 uchun)
                    if (response != null && response.code() == 429) {
                        val oldLabel = activeKey.label
                        _agentState.value = AgentState.Thinking("429 limiti: keyingi kalitga o'tilmoqda...")
                        val rotatedKey = apiKeyRepository.rotateOnRateLimit(
                            activeKey.id,
                            "HTTP 429 Too Many Requests"
                        )

                        if (rotatedKey != null) {
                            _agentState.value = AgentState.RotatingKey(
                                oldLabel = oldLabel,
                                newLabel = rotatedKey.label,
                                reason = "429 Limit bo'yicha rotatsiya"
                            )
                            activeKey = rotatedKey
                            currentKey = rotatedKey

                            // Yangi kalit bilan so'rovni qayta yuborish
                            response = callGemini(currentModel, activeKey.key, body)
                        } else if (currentModel != FALLBACK_MODEL) {
                            // Barcha kalitlar limitga yetgan bo'lsa, arzon zaxira modelga (Flash-Lite) o'tish
                            currentModel = FALLBACK_MODEL
                            _agentState.value = AgentState.Thinking("Zaxira Flash-Lite modeliga o'tildi...")
                            response = callGemini(currentModel, activeKey.key, body)
                        }
                    }

                    if (response == null || !response.isSuccessful) {
                        val errBody = response?.errorBody()?.string() ?: "Tarmoq xatosi"
                        val errText = "Gemini so'rovida xatolik (${response?.code() ?: 0}): $errBody"
                        chatRepository.addModelMessage(errText, currentModel, activeKey.label)
                        _agentState.value = AgentState.Error(errText)
                        return@launch
                    }

                    // Kalit ishlatilganligini qayd etish
                    apiKeyRepository.recordKeyUsage(activeKey.id)

                    val rawResponseString = response.body()?.string() ?: "{}"
                    val responseJson = JSONObject(rawResponseString)

                    val candidates = responseJson.optJSONArray("candidates")
                    if (candidates == null || candidates.length() == 0) {
                        val noResp = "Modeldan javob olinmadi."
                        chatRepository.addModelMessage(noResp, currentModel, activeKey.label)
                        _agentState.value = AgentState.Idle
                        return@launch
                    }

                    val firstCandidate = candidates.getJSONObject(0)
                    val contentObj = firstCandidate.optJSONObject("content")
                    val partsArray = contentObj?.optJSONArray("parts")

                    // Model bitta javobda bir nechta funksiyani (parallel) chaqirishi mumkin.
                    // Har bir chaqiruv uchun alohida javob qaytarilishi shart.
                    val modelParts = mutableListOf<GeminiPart>()
                    val functionCalls = mutableListOf<FunctionCall>()
                    val textBuilder = StringBuilder()

                    if (partsArray != null) {
                        for (i in 0 until partsArray.length()) {
                            val partObj = partsArray.optJSONObject(i) ?: continue
                            if (partObj.optBoolean("thought", false)) continue

                            val part = GeminiPart.fromJson(partObj)
                            val call = part.functionCall
                            if (call != null) {
                                functionCalls.add(call)
                                // thoughtSignature saqlanib qoladi
                                modelParts.add(part)
                            } else if (part.text != null) {
                                textBuilder.append(part.text)
                            }
                        }
                    }

                    if (functionCalls.isNotEmpty()) {
                        // A) Model VOSITA (functionCall) talab qildi
                        conversationContents.add(GeminiContent(role = "model", parts = modelParts))

                        val responseParts = mutableListOf<GeminiPart>()

                        for (call in functionCalls) {
                            val toolName = call.name
                            val toolArgs = call.args

                            _agentState.value = AgentState.ExecutingTool(toolName, toolArgs)

                            // 1. Tool chaqiruvini chatga va logga saqlash
                            chatRepository.addToolCallMessage(toolName, JSONObject(toolArgs).toString())
                            actionLogDao.insertLog(
                                AgentActionLogEntity(
                                    actionType = AgentActionLogEntity.TYPE_TOOL_EXECUTION,
                                    description = "Vosita chaqirildi: $toolName, argumentlar: $toolArgs",
                                    isSuccess = true
                                )
                            )

                            // 2. Xavfli amallar uchun foydalanuvchi tasdig'ini kutish, so'ng bajarish
                            val tool = toolDispatcher.getTool(toolName)
                            val approved = if (tool != null && tool.needsConfirmation(toolArgs)) {
                                awaitConfirmation(toolName, toolArgs)
                            } else {
                                true
                            }
                            _agentState.value = AgentState.ExecutingTool(toolName, toolArgs)
                            val toolResult = if (approved) {
                                toolDispatcher.executeTool(toolName, toolArgs)
                            } else {
                                ToolExecutionResult(
                                    isSuccess = false,
                                    output = mapOf("error" to "Foydalanuvchi amalni tasdiqlamadi yoki vaqt tugadi. Amal BAJARILMADI."),
                                    userSummary = "Amal bajarilmadi: foydalanuvchi tasdiqlamadi ($toolName)."
                                )
                            }

                            // 3. Natijani chatga saqlash
                            chatRepository.addToolResultMessage(
                                toolName = toolName,
                                resultSummary = toolResult.userSummary,
                                rawResultJson = JSONObject(toolResult.output).toString()
                            )

                            // 4. Modelga qaytariladigan javob
                            responseParts.add(
                                GeminiPart(
                                    functionResponse = FunctionResponse(
                                        name = toolName,
                                        response = toolResult.output
                                    )
                                )
                            )
                        }

                        conversationContents.add(GeminiContent(role = "user", parts = responseParts))

                        _agentState.value = AgentState.Thinking("Vosita natijasi tahlil qilinmoqda...")
                        // Tsikl davom etadi va natija Gemini'ga boradi
                    } else {
                        // B) Final matnli javob olindi
                        val finalText = textBuilder.toString().ifBlank { "Javob mavjud emas." }
                        chatRepository.addModelMessage(finalText, currentModel, activeKey.label)

                        isCompleted = true
                        _agentState.value = AgentState.Idle

                        // Ovoz chiqarish (TTS) so'rovi bo'lsa
                        onSpeechRequested?.invoke(finalText)
                    }
                }

                if (!isCompleted) {
                    val limitMsg = "Kotib vazifani yakunlash uchun maksimal qadamlar limitiga ($MAX_AGENT_STEPS ta) yetdi."
                    chatRepository.addModelMessage(limitMsg, currentModel, currentKey.label)
                    _agentState.value = AgentState.Idle
                }

            } catch (e: CancellationException) {
                _agentState.value = AgentState.Idle
            } catch (e: Exception) {
                val err = "Xatolik yuz berdi: ${e.message}"
                chatRepository.addModelMessage(err, null, null)
                _agentState.value = AgentState.Error(err)
            }
        }
    }

    /**
     * Tarmoq xatolarida (internet yo'q, timeout) null qaytaradi; bekor qilishni (cancel) esa o'tkazib yuboradi.
     */
    private suspend fun callGemini(
        model: String,
        apiKey: String,
        body: okhttp3.RequestBody
    ): retrofit2.Response<okhttp3.ResponseBody>? {
        return try {
            RetrofitClient.api.generateContent(
                model = model,
                apiKey = apiKey,
                requestBody = body
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    private fun buildRequestBody(contents: List<GeminiContent>): JSONObject {
        val root = JSONObject()

        // 1. Contents massivi
        val contentsArr = JSONArray()
        contents.forEach { contentsArr.put(it.toJson()) }
        root.put("contents", contentsArr)

        // 2. Tools
        root.put("tools", toolDispatcher.buildGeminiToolsJson())

        // 3. System instruction
        val sysInstructionObj = JSONObject().apply {
            put("parts", JSONArray().apply {
                put(JSONObject().put("text", SYSTEM_PROMPT))
            })
        }
        root.put("systemInstruction", sysInstructionObj)

        // 4. Generation config
        val genConfig = JSONObject().apply {
            put("temperature", 0.3)
        }
        root.put("generationConfig", genConfig)

        return root
    }
}
