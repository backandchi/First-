package com.example.kotib.domain.agent.tools.builtin

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.kotib.domain.agent.tools.AgentTool
import com.example.kotib.domain.agent.tools.ToolExecutionResult
import com.example.kotib.domain.automation.ContactResolver
import com.example.kotib.domain.automation.PackageResolver
import com.example.kotib.domain.automation.RootShellManager
import com.example.kotib.service.KotibAccessibilityService
import kotlinx.coroutines.delay

/**
 * Ilovalarni ochish, qidirish, chatlarga xabar yozish va ro'yxatini olish.
 * Ekranga bosish/surish/matn kiritish uchun 'root_control' vositasidan, ekranni o'qish
 * uchun 'automate_ui' vositasidan foydalaning.
 */
class UniversalAppControllerTool(
    private val context: Context,
    private val packageResolver: PackageResolver,
    private val contactResolver: ContactResolver,
    private val shellManager: RootShellManager
) : AgentTool {

    override val name: String = "control_installed_apps"
    override val description: String =
        "Telefondagi ilovalarni ochish (launch_app), to'xtatish (close_app), Telegram/WhatsApp/SMS " +
            "chatlariga xabar yuborish (send_chat_message), YouTube/brauzerda qidirish (open_and_search), " +
            "barcha o'rnatilgan ilovalar ro'yxatini olish (list_apps)."

    override val parametersSchema: Map<String, Any?> = mapOf(
        "type" to "OBJECT",
        "properties" to mapOf(
            "action" to mapOf(
                "type" to "STRING",
                "description" to "'send_chat_message', 'open_and_search', 'launch_app', 'close_app', 'list_apps'"
            ),
            "app" to mapOf("type" to "STRING", "description" to "Ilova nomi: 'telegram', 'whatsapp', 'sms', 'youtube', 'chrome' yoki istalgan o'rnatilgan ilova nomi"),
            "recipient" to mapOf("type" to "STRING", "description" to "Kontakt nomi (masalan 'Ali') yoki telefon raqami/username (masalan '+998901234567', '@ali')"),
            "text" to mapOf("type" to "STRING", "description" to "Xabar matni yoki qidiruv so'zi")
        ),
        "required" to listOf("action")
    )

    override val requiresConfirmation: Boolean = false

    override suspend fun execute(args: Map<String, Any?>): ToolExecutionResult {
        val action = args["action"]?.toString() ?: "launch_app"
        val app = args["app"]?.toString()?.lowercase().orEmpty()
        val recipient = args["recipient"]?.toString().orEmpty()
        val text = args["text"]?.toString().orEmpty()

        return when (action.lowercase()) {
            "send_chat_message" -> sendChatMessage(app, recipient, text)
            "open_and_search" -> openAndSearch(app, text)
            "list_apps" -> listInstalledApps()
            "close_app" -> closeApp(app)
            else -> launchApp(app)
        }
    }

    private fun listInstalledApps(): ToolExecutionResult {
        val apps = packageResolver.launchableApps()
        val preview = apps.take(30).joinToString(", ") { it.label }
        return ToolExecutionResult(
            isSuccess = true,
            output = mapOf("count" to apps.size, "apps" to apps.map { it.packageName }),
            userSummary = "Telefonda jami ${apps.size} ta ilova o'rnatilgan:\n$preview${if (apps.size > 30) "..." else ""}"
        )
    }

    private fun launchApp(app: String): ToolExecutionResult {
        if (app.isBlank()) {
            return ToolExecutionResult(false, mapOf("error" to "app kerak"), "Qaysi ilovani ochish kerakligini ayting.")
        }
        val pkg = packageResolver.resolve(app)
            ?: return ToolExecutionResult(false, mapOf("error" to "topilmadi"), "'$app' nomli o'rnatilgan ilova topilmadi.")
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: return ToolExecutionResult(false, mapOf("error" to "launch intent yo'q"), "'$app' ni ochib bo'lmadi.")
        return try {
            context.startActivity(intent.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            ToolExecutionResult(true, mapOf("package" to pkg), "'$app' ochildi.")
        } catch (e: Exception) {
            ToolExecutionResult(false, mapOf("error" to (e.message ?: "xato")), "'$app' ni ochib bo'lmadi: ${e.message}")
        }
    }

    private suspend fun closeApp(app: String): ToolExecutionResult {
        if (app.isBlank()) return ToolExecutionResult(false, mapOf("error" to "app kerak"), "Qaysi ilovani to'xtatish kerakligini ayting.")
        val pkg = packageResolver.resolve(app)
            ?: return ToolExecutionResult(false, mapOf("error" to "topilmadi"), "'$app' nomli o'rnatilgan ilova topilmadi.")
        val r = shellManager.forceStopPackage(pkg, useRoot = true)
        return ToolExecutionResult(
            isSuccess = r.isSuccess,
            output = mapOf("package" to pkg, "error" to r.error),
            userSummary = if (r.isSuccess) "'$app' to'xtatildi."
            else "'$app' ni to'xtatib bo'lmadi (root huquqi kerak): ${r.error}"
        )
    }

    private suspend fun sendChatMessage(app: String, recipient: String, text: String): ToolExecutionResult {
        if (text.isBlank()) {
            return ToolExecutionResult(false, mapOf("error" to "text kerak"), "Qanday xabar yuborish kerakligini ayting.")
        }

        return when {
            app.contains("telegram") -> {
                val username = recipient.removePrefix("@").trim()
                val isLikelyUsername = username.isNotBlank() && username.none { it.isDigit() } && username.all { it.isLetterOrDigit() || it == '_' }

                val uri = when {
                    isLikelyUsername -> Uri.parse("https://t.me/$username")
                    recipient.isNotBlank() -> {
                        // Raqam yoki ism berilgan — Telegram kontakt nomi bo'yicha o'z ichida qidiradi,
                        // shuning uchun kontaktlar bazasidan avval haqiqiy raqamni topishga harakat qilamiz.
                        when (val resolution = contactResolver.resolve(recipient)) {
                            is ContactResolver.Resolution.Found -> Uri.parse("https://t.me/+${resolution.number.removePrefix("+")}")
                            is ContactResolver.Resolution.Ambiguous -> return ambiguous(resolution.candidates)
                            is ContactResolver.Resolution.Failed -> return ToolExecutionResult(
                                false, mapOf("error" to resolution.reason), resolution.reason
                            )
                        }
                    }
                    else -> null
                }

                if (uri == null) {
                    return ToolExecutionResult(false, mapOf("error" to "recipient kerak"), "Kimga yozish kerakligini (ism, @username yoki raqam) ayting.")
                }

                val opened = openTelegramChat(uri)
                if (!opened) {
                    return ToolExecutionResult(false, mapOf("error" to "Telegram ochilmadi"), "Telegram o'rnatilmagan yoki chatni ochib bo'lmadi.")
                }

                deliverViaAccessibility(text)
            }

            app.contains("whatsapp") -> {
                val resolution = contactResolver.resolve(recipient)
                val phone = when (resolution) {
                    is ContactResolver.Resolution.Found -> resolution.number.removePrefix("+")
                    is ContactResolver.Resolution.Ambiguous -> return ambiguous(resolution.candidates)
                    is ContactResolver.Resolution.Failed -> return ToolExecutionResult(false, mapOf("error" to resolution.reason), resolution.reason)
                }

                val uri = Uri.parse("https://api.whatsapp.com/send?phone=$phone&text=${Uri.encode(text)}")
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.whatsapp")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(context.packageManager) == null) {
                    return ToolExecutionResult(false, mapOf("error" to "WhatsApp o'rnatilmagan"), "WhatsApp o'rnatilmagan.")
                }
                context.startActivity(intent)
                delay(1800)
                val sent = clickSend()
                ToolExecutionResult(
                    isSuccess = true,
                    output = mapOf("app" to "WhatsApp", "recipient" to phone, "text" to text, "autoSent" to sent),
                    userSummary = if (sent) "WhatsApp'da $phone'ga xabar yuborildi."
                    else "WhatsApp'da $phone bilan chat ochildi, xabar matni kiritilgan — yuborish tugmasini bosib tasdiqlang."
                )
            }

            else -> {
                val resolution = contactResolver.resolve(recipient)
                val phone = when (resolution) {
                    is ContactResolver.Resolution.Found -> resolution.number
                    is ContactResolver.Resolution.Ambiguous -> return ambiguous(resolution.candidates)
                    is ContactResolver.Resolution.Failed -> return ToolExecutionResult(false, mapOf("error" to resolution.reason), resolution.reason)
                }
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone")).apply {
                    putExtra("sms_body", text)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(context.packageManager) == null) {
                    return ToolExecutionResult(false, mapOf("error" to "SMS ilovasi topilmadi"), "SMS ilovasi topilmadi.")
                }
                context.startActivity(intent)
                delay(1200)
                val sent = clickSend()
                ToolExecutionResult(
                    isSuccess = true,
                    output = mapOf("app" to "SMS", "recipient" to phone, "text" to text, "autoSent" to sent),
                    userSummary = if (sent) "SMS orqali $phone'ga xabar yuborildi."
                    else "SMS $phone uchun tayyorlandi — yuborish tugmasini bosib tasdiqlang."
                )
            }
        }
    }

    private fun openTelegramChat(uri: Uri): Boolean {
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("org.telegram.messenger")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent); true
        } else false
    }

    /** Accessibility orqali fokusdagi matn maydoniga yozadi va "Yuborish" tugmasini bosishga harakat qiladi. */
    private suspend fun deliverViaAccessibility(text: String): ToolExecutionResult {
        if (!KotibAccessibilityService.isRunning()) {
            return ToolExecutionResult(
                isSuccess = false,
                output = mapOf("error" to "Accessibility o'chiq"),
                userSummary = "Chat ochildi, lekin xabarni avtomatik yozib bo'lmadi: Accessibility xizmati o'chiq. Sozlamalar → Maxsus imkoniyatlardan yoqing, keyin o'zingiz yozib yuboring."
            )
        }
        delay(1500)
        val typed = KotibAccessibilityService.setFocusedText(text)
        if (!typed) {
            return ToolExecutionResult(
                isSuccess = false,
                output = mapOf("error" to "matn maydoni topilmadi"),
                userSummary = "Chat ochildi, lekin yozish maydoni topilmadi. Xabarni qo'lda yozing."
            )
        }
        delay(300)
        val sent = clickSend()
        return ToolExecutionResult(
            isSuccess = true,
            output = mapOf("text" to text, "autoSent" to sent),
            userSummary = if (sent) "Xabar yozildi va yuborildi." else "Xabar yozildi, lekin yuborish tugmasi topilmadi — bosib tasdiqlang."
        )
    }

    private fun clickSend(): Boolean =
        KotibAccessibilityService.isRunning() && (
            KotibAccessibilityService.clickNodeByText("Send") ||
                KotibAccessibilityService.clickNodeByText("Yuborish") ||
                KotibAccessibilityService.clickNodeByText("SMS")
            )

    private fun ambiguous(candidates: List<ContactResolver.Contact>): ToolExecutionResult {
        val list = candidates.joinToString("\n") { "${it.name}: ${it.number}" }
        return ToolExecutionResult(
            isSuccess = false,
            output = mapOf("candidates" to candidates.map { it.number }),
            userSummary = "Bir nechta mos kontakt topildi, aniqlashtiring:\n$list"
        )
    }

    private fun openAndSearch(app: String, query: String): ToolExecutionResult {
        if (query.isBlank()) return ToolExecutionResult(false, mapOf("error" to "text kerak"), "Nimani qidirish kerakligini ayting.")
        return try {
            when {
                app.contains("youtube") -> {
                    val intent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage("com.google.android.youtube")
                        putExtra("query", query)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(context.packageManager) != null) {
                        context.startActivity(intent)
                    } else {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                    ToolExecutionResult(true, mapOf("app" to "YouTube", "query" to query), "YouTube'da '$query' qidirildi.")
                }
                else -> {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    ToolExecutionResult(true, mapOf("query" to query), "Brauzerda '$query' qidirildi.")
                }
            }
        } catch (e: Exception) {
            ToolExecutionResult(false, mapOf("error" to (e.message ?: "xato")), "Qidiruvni bajarib bo'lmadi: ${e.message}")
        }
    }
}
