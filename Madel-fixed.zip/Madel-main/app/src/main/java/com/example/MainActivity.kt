package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.kotib.ui.MainScreen
import com.example.kotib.ui.automation.AutomationViewModel
import com.example.kotib.ui.chat.ChatViewModel
import com.example.kotib.ui.integrations.IntegrationsViewModel
import com.example.kotib.ui.messages.MessagesViewModel
import com.example.ui.theme.KotibTheme

class MainActivity : ComponentActivity() {

    // Android 13+ da bildirishnomalar (foreground service, qo'ng'iroq) uchun ruxsat so'ralishi shart
    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val app = application as KotibApp
        val container = app.container

        setContent {
            KotibTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val chatViewModel: ChatViewModel = viewModel(
                        factory = ChatViewModel.Factory(container, applicationContext)
                    )
                    val messagesViewModel: MessagesViewModel = viewModel(
                        factory = MessagesViewModel.Factory(container)
                    )
                    val integrationsViewModel: IntegrationsViewModel = viewModel(
                        factory = IntegrationsViewModel.Factory(container)
                    )
                    val automationViewModel: AutomationViewModel = viewModel(
                        factory = AutomationViewModel.Factory(container)
                    )

                    MainScreen(
                        container = container,
                        chatViewModel = chatViewModel,
                        messagesViewModel = messagesViewModel,
                        integrationsViewModel = integrationsViewModel,
                        automationViewModel = automationViewModel
                    )
                }
            }
        }
    }
}
