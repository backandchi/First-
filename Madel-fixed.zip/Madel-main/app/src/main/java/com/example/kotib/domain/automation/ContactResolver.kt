package com.example.kotib.domain.automation

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/**
 * Kontakt nomini haqiqiy telefon raqamiga aylantiradi (READ_CONTACTS ruxsati kerak).
 * Hech qachon raqamni o'zidan to'qimaydi.
 */
class ContactResolver(private val context: Context) {

    data class Contact(val name: String, val number: String)

    sealed interface Resolution {
        data class Found(val number: String, val name: String?) : Resolution
        data class Ambiguous(val candidates: List<Contact>) : Resolution
        data class Failed(val reason: String) : Resolution
    }

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    private fun normalize(number: String): String = number.filter { it.isDigit() || it == '+' }

    fun search(query: String, limit: Int = 8): List<Contact> {
        if (!hasPermission() || query.isBlank()) return emptyList()
        val result = mutableListOf<Contact>()
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%${query.trim()}%"),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { c ->
                while (c.moveToNext() && result.size < limit * 3) {
                    val name = c.getString(0) ?: continue
                    val number = normalize(c.getString(1) ?: continue)
                    if (number.isNotEmpty()) result.add(Contact(name, number))
                }
            }
        } catch (_: Exception) {
        }
        return result.distinctBy { it.number }.take(limit)
    }

    /** Raqam (+998...) yoki kontakt nomini aniq telefon raqamiga aylantiradi. */
    fun resolve(recipient: String): Resolution {
        val r = recipient.trim()
        if (r.isEmpty()) return Resolution.Failed("Oluvchi ko'rsatilmadi")

        val looksLikeNumber = r.none { it.isLetter() } && r.count { it.isDigit() } >= 5
        if (looksLikeNumber) return Resolution.Found(normalize(r), null)

        if (!hasPermission()) {
            return Resolution.Failed("Kontaktlarga ruxsat berilmagan, shuning uchun '$r' ismini raqamga aylantirib bo'lmaydi. Sozlamalar → Ruxsatlar bo'limida ruxsat bering yoki telefon raqamini ayting.")
        }

        val matches = search(r)
        if (matches.isEmpty()) return Resolution.Failed("'$r' nomli kontakt topilmadi")

        val byName = matches.groupBy { it.name.lowercase() }
        val exact = matches.filter { it.name.equals(r, ignoreCase = true) }
        val pool = if (exact.isNotEmpty()) exact else matches
        return if (pool.size == 1 || byName.size == 1 && pool.map { it.number }.distinct().size == 1) {
            Resolution.Found(pool.first().number, pool.first().name)
        } else {
            Resolution.Ambiguous(pool)
        }
    }
}
