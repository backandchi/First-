package com.example.kotib.shizuku

import java.io.InputStream
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Shizuku ushbu klassni ALOHIDA JARAYONDA (shell yoki root UID bilan) ishga tushiradi.
 * E'tibor: Shizuku talab qiladigan aniq konstruktor imzosi — bo'sh konstruktor.
 * Bu yerdagi kod to'g'ridan-to'g'ri shell/root huquqi bilan ishlaydi, "su" kerak emas.
 */
class ShizukuUserService : IShizukuUserService.Stub() {

    override fun execCommand(command: String, timeoutMs: Long): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()

            var out = ""
            val reader = thread(start = true, isDaemon = true) {
                out = readCapped(process.inputStream)
            }

            val finished = process.waitFor(
                if (timeoutMs > 0) timeoutMs else 12_000L,
                TimeUnit.MILLISECONDS
            )
            if (!finished) {
                process.destroyForcibly()
                return "EXIT:-2\nVaqt tugadi"
            }
            reader.join(2000)
            "EXIT:${process.exitValue()}\n$out"
        } catch (e: Exception) {
            "EXIT:-1\n${e.message ?: "Shizuku orqali bajarib bo'lmadi"}"
        }
    }

    override fun destroy() {
        // Shizuku bu jarayonni o'zi boshqaradi; qo'shimcha tozalash shart emas.
    }

    private fun readCapped(stream: InputStream, cap: Int = 60_000): String {
        val sb = StringBuilder()
        val buf = CharArray(4096)
        stream.bufferedReader().use { r ->
            while (true) {
                val n = r.read(buf)
                if (n < 0) break
                if (sb.length < cap) sb.append(buf, 0, minOf(n, cap - sb.length))
            }
        }
        return sb.toString()
    }
}
