package com.example.kotib.domain.agent.tools.builtin

import android.content.Context
import com.example.kotib.domain.agent.tools.AgentTool
import com.example.kotib.domain.agent.tools.ToolExecutionResult
import com.example.kotib.domain.automation.RootShellManager
import java.io.File

/**
 * Telefondagi fayllar bilan ishlash: ro'yxatlash, o'qish, yozish, o'chirish, papka yaratish.
 * Avval oddiy fayl ruxsatlari bilan (ilova papkasi, Download, DCIM va h.k.) ishlaydi;
 * ular yetmasa (masalan /data/... yoki boshqa ilova papkasi) va root mavjud bo'lsa, `su` orqali bajaradi.
 */
class FileManagerTool(
    private val context: Context,
    private val shellManager: RootShellManager
) : AgentTool {

    override val name: String = "manage_files"
    override val description: String =
        "Telefondagi fayl va papkalarni boshqarish: ro'yxatini ko'rish (list), matn faylini o'qish (read), " +
            "matn faylini yozish (write), fayl yoki papkani o'chirish (delete), yangi papka yaratish (mkdir). " +
            "Yo'l ko'rsatilmasa standart hujjatlar/yuklamalar papkasi ishlatiladi."

    override val parametersSchema: Map<String, Any?> = mapOf(
        "type" to "OBJECT",
        "properties" to mapOf(
            "action" to mapOf("type" to "STRING", "description" to "'list', 'read', 'write', 'delete', 'mkdir'"),
            "path" to mapOf("type" to "STRING", "description" to "Fayl yoki papka yo'li. Nisbiy bo'lsa (masalan 'notes.txt'), Download papkasiga nisbatan olinadi."),
            "content" to mapOf("type" to "STRING", "description" to "'write' amali uchun fayl matni"),
            "append" to mapOf("type" to "BOOLEAN", "description" to "'write' uchun: true bo'lsa faylga qo'shiladi, aks holda ustidan yoziladi")
        ),
        "required" to listOf("action", "path")
    )

    override val requiresConfirmation: Boolean = false

    override fun needsConfirmation(args: Map<String, Any?>): Boolean =
        (args["action"]?.toString()?.lowercase()) == "delete"

    // Android 10+ da umumiy Download papkasiga to'g'ridan-to'g'ri fayl yozish (scoped storage)
    // maxsus ruxsat yoki MediaStore talab qiladi. Shuning uchun nisbiy yo'llar ilovaning o'z
    // tashqi papkasiga (ruxsatsiz ishlaydi, lekin boshqa ilovalarga ko'rinmaydi) yo'naltiriladi.
    // Umumiy Download/DCIM'ni o'qish uchun to'liq yo'l (masalan "/storage/emulated/0/Download/x.txt") ishlatilsin.
    private val appFilesDir: File
        get() = context.getExternalFilesDir(null) ?: context.filesDir

    private fun resolve(path: String): File {
        val f = File(path)
        return if (f.isAbsolute) f else File(appFilesDir, path)
    }

    private val maxReadBytes = 300_000

    override suspend fun execute(args: Map<String, Any?>): ToolExecutionResult {
        val action = args["action"]?.toString()?.lowercase() ?: "list"
        val rawPath = args["path"]?.toString()?.trim().orEmpty()
        if (rawPath.isBlank() && action != "list") {
            return ToolExecutionResult(false, mapOf("error" to "Yo'l ko'rsatilmadi"), "Fayl yo'lini ayting.")
        }
        val file = resolve(rawPath.ifBlank { "." })

        return when (action) {
            "list" -> listDir(file)
            "read" -> readFile(file)
            "write" -> writeFile(file, args["content"]?.toString().orEmpty(), (args["append"] as? Boolean) ?: false)
            "delete" -> deleteFile(file)
            "mkdir" -> mkdir(file)
            else -> ToolExecutionResult(false, mapOf("error" to "Noma'lum amal: $action"), "Noma'lum amal: $action")
        }
    }

    private suspend fun listDir(dir: File): ToolExecutionResult {
        if (dir.exists() && dir.isDirectory && dir.canRead()) {
            val entries = dir.listFiles()?.sortedBy { it.name.lowercase() } ?: emptyList()
            val summary = entries.joinToString("\n") { "${if (it.isDirectory) "[Papka] " else ""}${it.name}${if (!it.isDirectory) " (${it.length()} bayt)" else ""}" }
            return ToolExecutionResult(
                true,
                mapOf("path" to dir.absolutePath, "count" to entries.size),
                if (entries.isEmpty()) "'${dir.absolutePath}' bo'sh." else "'${dir.absolutePath}' ichidagilar:\n$summary"
            )
        }
        if (shellManager.isRootAvailable()) {
            val r = shellManager.executeCommand("ls -la ${shellManager.quote(dir.absolutePath)}", asRoot = true)
            return if (r.isSuccess) {
                ToolExecutionResult(true, mapOf("path" to dir.absolutePath), "'${dir.absolutePath}' ichidagilar (root):\n${r.output}")
            } else {
                ToolExecutionResult(false, mapOf("error" to r.error), "'${dir.absolutePath}' ni o'qib bo'lmadi: ${r.error}")
            }
        }
        return ToolExecutionResult(false, mapOf("error" to "Topilmadi yoki ruxsat yo'q"), "'${dir.absolutePath}' topilmadi yoki o'qish ruxsati yo'q.")
    }

    private suspend fun readFile(file: File): ToolExecutionResult {
        if (file.exists() && file.isFile && file.canRead()) {
            if (file.length() > maxReadBytes) {
                return ToolExecutionResult(false, mapOf("error" to "Fayl juda katta"), "'${file.name}' juda katta (${file.length()} bayt), to'liq o'qib bo'lmaydi.")
            }
            val text = file.readText()
            return ToolExecutionResult(true, mapOf("path" to file.absolutePath, "content" to text), "'${file.name}' tarkibi:\n$text")
        }
        if (shellManager.isRootAvailable()) {
            val r = shellManager.executeCommand("cat ${shellManager.quote(file.absolutePath)}", asRoot = true)
            return if (r.isSuccess) {
                ToolExecutionResult(true, mapOf("path" to file.absolutePath, "content" to r.output), "'${file.name}' tarkibi (root):\n${r.output}")
            } else {
                ToolExecutionResult(false, mapOf("error" to r.error), "'${file.name}' ni o'qib bo'lmadi: ${r.error}")
            }
        }
        return ToolExecutionResult(false, mapOf("error" to "Topilmadi"), "'${file.absolutePath}' topilmadi yoki o'qish ruxsati yo'q.")
    }

    private fun writeFile(file: File, content: String, append: Boolean): ToolExecutionResult {
        return try {
            file.parentFile?.mkdirs()
            if (append) file.appendText(content) else file.writeText(content)
            ToolExecutionResult(true, mapOf("path" to file.absolutePath, "bytes" to content.length), "'${file.name}' ga yozildi (${content.length} belgi).")
        } catch (e: Exception) {
            ToolExecutionResult(false, mapOf("error" to (e.message ?: "xato")), "'${file.name}' ga yozib bo'lmadi: ${e.message}")
        }
    }

    private suspend fun deleteFile(file: File): ToolExecutionResult {
        if (file.exists()) {
            val ok = if (file.isDirectory) file.deleteRecursively() else file.delete()
            if (ok) return ToolExecutionResult(true, mapOf("path" to file.absolutePath), "'${file.name}' o'chirildi.")
        }
        if (shellManager.isRootAvailable()) {
            val r = shellManager.executeCommand("rm -rf ${shellManager.quote(file.absolutePath)}", asRoot = true)
            return if (r.isSuccess) ToolExecutionResult(true, mapOf("path" to file.absolutePath), "'${file.name}' o'chirildi (root).")
            else ToolExecutionResult(false, mapOf("error" to r.error), "'${file.name}' ni o'chirib bo'lmadi: ${r.error}")
        }
        return ToolExecutionResult(false, mapOf("error" to "Topilmadi yoki ruxsat yo'q"), "'${file.absolutePath}' ni o'chirib bo'lmadi.")
    }

    private fun mkdir(dir: File): ToolExecutionResult {
        val ok = dir.exists() && dir.isDirectory || dir.mkdirs()
        return if (ok) ToolExecutionResult(true, mapOf("path" to dir.absolutePath), "'${dir.absolutePath}' papkasi tayyor.")
        else ToolExecutionResult(false, mapOf("error" to "Yaratib bo'lmadi"), "'${dir.absolutePath}' papkasini yaratib bo'lmadi.")
    }
}
