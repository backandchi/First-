package com.example.kotib.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.KotibApp
import kotlinx.coroutines.launch

/** Telefon qayta yoqilgach rejalashtirilgan signallarni tiklaydi. */
class KotibBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val app = context?.applicationContext as? KotibApp ?: return
        val pending = goAsync()
        app.container.applicationScope.launch {
            try {
                app.container.automationScheduler.rescheduleAll()
            } finally {
                pending.finish()
            }
        }
    }
}
