package com.example.kotib.data.api

import android.util.Log
import com.example.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val BOT_TOKEN_REGEX = Regex("/bot[^/\\s]+/")
    private val KEY_PARAM_REGEX = Regex("([?&]key=)[^&\\s]+")

    /** Loglardan maxfiy kalit va tokenlarni olib tashlaydi (Telegram bot tokeni, ?key=...). */
    private fun redact(message: String): String =
        message
            .replace(BOT_TOKEN_REGEX, "/bot***/")
            .replace(KEY_PARAM_REGEX, "$1***")

    // Xavfsizlik qoidasi: release build'da umuman log yozilmaydi,
    // debug build'da esa maxfiy qismlar yashiriladi.
    private val loggingInterceptor = HttpLoggingInterceptor(
        object : HttpLoggingInterceptor.Logger {
            override fun log(message: String) {
                Log.d("KotibHttp", redact(message))
            }
        }
    ).apply {
        level = if (BuildConfig.DEBUG) {
            HttpLoggingInterceptor.Level.BASIC
        } else {
            HttpLoggingInterceptor.Level.NONE
        }
    }

    val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(loggingInterceptor)
        .build()

    val api: GeminiApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .build()
            .create(GeminiApi::class.java)
    }
}
