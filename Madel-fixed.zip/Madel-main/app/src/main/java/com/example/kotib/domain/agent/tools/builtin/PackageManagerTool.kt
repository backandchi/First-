package com.example.kotib.domain.agent.tools.builtin

import com.example.kotib.domain.agent.tools.AgentTool
import com.example.kotib.domain.agent.tools.ToolExecutionResult
import com.example.kotib.domain.automation.PackageResolver
import com.example.kotib.domain.automation.RootShellManager

/**
 * O'rnatilgan ilovalarni boshqarish: ro'yxat, qidirish, o'chirish (uninstall), ma'lumotlarni
 * tozalash, ruxsat berish/olib tashlash. O'chirish va o'rnatish root (su `pm`) talab qiladi.
 */
class PackageManagerTool(
    private val resolver: PackageResolver,
    private val shellManager: RootShellManager
) : AgentTool {

    override val name: String = "manage_packages"
    override val description: String =
        "O'rnatilgan ilovalarni boshqarish: ro'yxatini olish yoki qidirish (list/search), " +
            "to'xtatish (force_stop), keshni tozalash (clear_data), butunlay o'chirish (uninstall, root kerak), " +
            "ruxsat berish (grant_permission, root kerak)."

    override val parametersSchema: Map<String, Any?> = mapOf(
        "type" to "OBJECT",
        "properties" to mapOf(
            "action" to mapOf("type" to "STRING", "description" to "'list', 'search', 'force_stop', 'clear_data', 'uninstall', 'grant_permission'"),
            "app" to mapOf("type" to "STRING", "description" to "Ilova nomi (masalan 'Telegram') yoki paket nomi (masalan 'org.telegram.messenger')"),
            "permission" to mapOf("type" to "STRING", "description" to "grant_permission uchun to'liq ruxsat nomi, masalan 'android.permission.CAMERA'")
        ),
        "required" to listOf("action")
    )

    override val requiresConfirmation: Boolean = false

    override fun needsConfirmation(args: Map<String, Any?>): Boolean =
        (args["action"]?.toString()?.lowercase()) in setOf("uninstall", "clear_data")

    override suspend fun execute(args: Map<String, Any?>): ToolExecutionResult {
        val action = args["action"]?.toString()?.lowercase() ?: "list"
        val appQuery = args["app"]?.toString().orEmpty()

        if (action == "list") {
            val apps = resolver.launchableApps()
            val preview = apps.take(40).joinToString("\n") { "${it.label} — ${it.packageName}" }
            return ToolExecutionResult(
                true,
                mapOf("count" to apps.size),
                "Jami ${apps.size} ta ilova o'rnatilgan:\n$preview${if (apps.size > 40) "\n... va yana ${apps.size - 40} ta" else ""}"
            )
        }

        if (action == "search") {
            if (appQuery.isBlank()) return needApp()
            val matches = resolver.search(appQuery)
            return if (matches.isEmpty()) {
                ToolExecutionResult(true, mapOf("count" to 0), "'$appQuery' bo'yicha ilova topilmadi.")
            } else {
                ToolExecutionResult(
                    true,
                    mapOf("count" to matches.size, "apps" to matches.map { it.packageName }),
                    "Topildi:\n" + matches.joinToString("\n") { "${it.label} — ${it.packageName}" }
                )
            }
        }

        if (appQuery.isBlank()) return needApp()
        val pkg = resolver.resolve(appQuery)
            ?: return ToolExecutionResult(
                false,
                mapOf("error" to "topilmadi"),
                "'$appQuery' nomli o'rnatilgan ilova topilmadi. Aniq nomini yoki 'search' amali bilan tekshiring."
            )

        return when (action) {
            "force_stop" -> {
                val r = shellManager.executeCommand("am force-stop ${shellManager.quote(pkg)}", asRoot = true)
                rootOutcome(r, "'$appQuery' to'xtatildi.", "'$appQuery' ni to'xtatib bo'lmadi")
            }
            "clear_data" -> {
                val r = shellManager.executeCommand("pm clear ${shellManager.quote(pkg)}", asRoot = true)
                rootOutcome(r, "'$appQuery' ma'lumotlari tozalandi.", "'$appQuery' ma'lumotlarini tozalab bo'lmadi")
            }
            "uninstall" -> {
                val r = shellManager.executeCommand("pm uninstall --user 0 ${shellManager.quote(pkg)}", asRoot = true, timeoutMs = 20_000L)
                rootOutcome(r, "'$appQuery' o'chirildi.", "'$appQuery' ni o'chirib bo'lmadi")
            }
            "grant_permission" -> {
                val permission = args["permission"]?.toString().orEmpty()
                if (permission.isBlank()) {
                    ToolExecutionResult(false, mapOf("error" to "permission kerak"), "Qaysi ruxsatni berish kerakligini aniq ayting (masalan android.permission.CAMERA).")
                } else {
                    val r = shellManager.executeCommand("pm grant ${shellManager.quote(pkg)} ${shellManager.quote(permission)}", asRoot = true)
                    rootOutcome(r, "'$appQuery' ga '$permission' ruxsati berildi.", "Ruxsat berib bo'lmadi")
                }
            }
            else -> ToolExecutionResult(false, mapOf("error" to "Noma'lum amal: $action"), "Noma'lum amal: $action")
        }
    }

    private fun needApp() = ToolExecutionResult(false, mapOf("error" to "app kerak"), "Qaysi ilova ekanini ayting.")

    private fun rootOutcome(r: com.example.kotib.domain.automation.ShellResult, okMsg: String, failPrefix: String) =
        ToolExecutionResult(
            isSuccess = r.isSuccess,
            output = mapOf("exitCode" to r.exitCode, "stdout" to r.output, "error" to r.error),
            userSummary = if (r.isSuccess) okMsg else "$failPrefix (root huquqi kerak): ${r.error.ifBlank { r.output }}"
        )
}
