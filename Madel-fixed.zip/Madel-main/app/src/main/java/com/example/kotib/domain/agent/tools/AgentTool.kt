package com.example.kotib.domain.agent.tools

/**
 * Kotib agentining har bir vositasi (tool) uchun umumiy interfeys
 */
interface AgentTool {
    val name: String
    val description: String
    val parametersSchema: Map<String, Any?>
    val requiresConfirmation: Boolean

    /**
     * Aniq argumentlarga qarab tasdiq kerakmi (masalan: faylni o'chirish, qayta yuklash).
     * Standart holatda [requiresConfirmation] qiymati ishlatiladi.
     */
    fun needsConfirmation(args: Map<String, Any?>): Boolean = requiresConfirmation

    suspend fun execute(args: Map<String, Any?>): ToolExecutionResult
}

data class ToolExecutionResult(
    val isSuccess: Boolean,
    val output: Map<String, Any?>,
    val userSummary: String
)
