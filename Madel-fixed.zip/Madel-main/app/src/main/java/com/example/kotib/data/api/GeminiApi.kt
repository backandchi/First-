package com.example.kotib.data.api

import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

interface GeminiApi {

    /**
     * Gemini REST API orqali kontent va vosita chaqiruvlarini generatsiya qilish.
     *
     * API kalit URL (?key=...) o'rniga `x-goog-api-key` sarlavhasida yuboriladi,
     * shunda u URL loglariga va proksi jurnallariga tushib qolmaydi.
     */
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Header("x-goog-api-key") apiKey: String,
        @Body requestBody: RequestBody
    ): Response<ResponseBody>
}
