package com.example.kotib.domain.automation

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

data class ShellResult(
    val exitCode: Int,
    val output: String,
    val error: String,
    val isSuccess: Boolean = exitCode == 0
)

/**
 * Haqiqiy shell (sh) va root (su) buyruqlarini bajaradi.
 * Har bir buyruq vaqt chegarasi bilan ishlaydi (su so'rovi osilib qolmasligi uchun).
 */
class RootShellManager(private val context: Context) {

    private val rootBinaries = listOf(
        "/system/bin/su",
        "/system/xbin/su",
        "/sbin/su",
        "/su/bin/su",
        "/system/sd/xbin/su",
        "/system/bin/failsafe/su",
        "/data/local/xbin/su",
        "/data/local/bin/su",
        "/data/local/su"
    )

    @Volatile private var cachedRoot: Boolean? = null
    @Volatile private var cachedAt: Long = 0L

    /**
     * Qurilmada root (su) haqiqatan ishlayotganini `su -c id` orqali tekshiradi.
     * Muvaffaqiyatli natija eslab qolinadi; muvaffaqiyatsizi 30 soniyadan keyin qayta tekshiriladi.
     */
    suspend fun isRootAvailable(forceRecheck: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        val cached = cachedRoot
        if (!forceRecheck && cached != null) {
            if (cached) return@withContext true
            if (System.currentTimeMillis() - cachedAt < 30_000L) return@withContext false
        }

        val hasBinary = rootBinaries.any { File(it).exists() }
        var ok = false
        if (hasBinary) {
            // su so'rovi (Magisk/KernelSU oynasi) chiqishi mumkin — foydalanuvchiga 20 soniya beramiz
            val r = run(arrayOf("su", "-c", "id"), 20_000L)
            ok = r.isSuccess && r.output.contains("uid=0")
        }
        cachedRoot = ok
        cachedAt = System.currentTimeMillis()
        ok
    }

    /**
     * Shell buyrug'ini bajaradi. asRoot = true bo'lsa `su -c`, aks holda `sh -c`.
     */
    suspend fun executeCommand(
        command: String,
        asRoot: Boolean = false,
        timeoutMs: Long = 12_000L
    ): ShellResult = withContext(Dispatchers.IO) {
        val shell = if (asRoot) "su" else "sh"
        run(arrayOf(shell, "-c", command), timeoutMs)
    }

    /** Root bo'lsa root bilan, bo'lmasa oddiy shell bilan bajaradi. */
    suspend fun executeBest(command: String, timeoutMs: Long = 12_000L): ShellResult =
        executeCommand(command, asRoot = isRootAvailable(), timeoutMs = timeoutMs)

    private fun run(cmd: Array<String>, timeoutMs: Long): ShellResult {
        return try {
            val process = ProcessBuilder(*cmd).start()
            var out = ""
            var err = ""
            val t1 = thread(start = true, isDaemon = true) { out = readCapped(process.inputStream) }
            val t2 = thread(start = true, isDaemon = true) { err = readCapped(process.errorStream) }

            val finished = process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            if (!finished) {
                process.destroyForcibly()
                return ShellResult(-2, "", "Vaqt tugadi (${timeoutMs / 1000} soniya)", false)
            }
            t1.join(2000)
            t2.join(2000)
            val code = process.exitValue()
            ShellResult(code, out.trim(), err.trim(), code == 0)
        } catch (e: Exception) {
            ShellResult(-1, "", e.message ?: "Buyruqni bajarib bo'lmadi", false)
        }
    }

    private fun readCapped(stream: InputStream, cap: Int = 60_000): String {
        val sb = StringBuilder()
        val buf = CharArray(4096)
        stream.bufferedReader().use { reader ->
            while (true) {
                val n = reader.read(buf)
                if (n < 0) break
                if (sb.length < cap) sb.append(buf, 0, minOf(n, cap - sb.length))
                // cap'dan oshganini o'qib tashlayveramiz (jarayon bloklanib qolmasin)
            }
        }
        return sb.toString()
    }

    /** Shell uchun xavfsiz bitta-tirnoqli qiymat: abc'd -> 'abc'\''d' */
    fun quote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    // ------------------------------------------------------------------
    // Input (bosish, surish, matn, tugmalar) — root talab qiladi
    // ------------------------------------------------------------------

    suspend fun tap(x: Int, y: Int, useRoot: Boolean = true): ShellResult =
        executeCommand("input tap $x $y", asRoot = useRoot)

    suspend fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Int = 300, useRoot: Boolean = true): ShellResult =
        executeCommand("input swipe $x1 $y1 $x2 $y2 $durationMs", asRoot = useRoot)

    suspend fun longPress(x: Int, y: Int, durationMs: Int = 800, useRoot: Boolean = true): ShellResult =
        swipe(x, y, x, y, durationMs, useRoot)

    /** Faqat ASCII matn uchun (unicode uchun DeviceInputController clipboard usulini ishlatadi). */
    suspend fun typeText(text: String, useRoot: Boolean = true): ShellResult {
        val prepared = text.replace(" ", "%s")
        return executeCommand("input text ${quote(prepared)}", asRoot = useRoot)
    }

    suspend fun pressKeyEvent(keyCode: Int, useRoot: Boolean = true): ShellResult =
        executeCommand("input keyevent $keyCode", asRoot = useRoot)

    suspend fun forceStopPackage(packageName: String, useRoot: Boolean = true): ShellResult =
        executeCommand("am force-stop ${quote(packageName)}", asRoot = useRoot)

    suspend fun clearPackageData(packageName: String, useRoot: Boolean = true): ShellResult =
        executeCommand("pm clear ${quote(packageName)}", asRoot = useRoot)

    suspend fun setBrightness(brightness: Int, useRoot: Boolean = true): ShellResult {
        val clamped = brightness.coerceIn(0, 255)
        return executeCommand(
            "settings put system screen_brightness_mode 0; settings put system screen_brightness $clamped",
            asRoot = useRoot
        )
    }

    suspend fun toggleWifi(enable: Boolean, useRoot: Boolean = true): ShellResult =
        executeCommand(if (enable) "svc wifi enable" else "svc wifi disable", asRoot = useRoot)

    suspend fun toggleBluetooth(enable: Boolean, useRoot: Boolean = true): ShellResult =
        executeCommand(if (enable) "svc bluetooth enable" else "svc bluetooth disable", asRoot = useRoot)
}
