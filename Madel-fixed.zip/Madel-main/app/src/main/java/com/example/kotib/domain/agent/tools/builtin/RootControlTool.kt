package com.example.kotib.domain.agent.tools.builtin

import com.example.kotib.domain.agent.tools.AgentTool
import com.example.kotib.domain.agent.tools.ToolExecutionResult
import com.example.kotib.domain.automation.RootShellManager
import com.example.kotib.domain.automation.ShellResult
import com.example.kotib.domain.automation.ShizukuShellManager
import com.example.kotib.service.KotibAccessibilityService
import kotlinx.coroutines.delay
import java.io.File

/**
 * Qurilmani pastki darajada boshqarish: ekranga bosish, surish, tugmalar, Wi-Fi/Bluetooth,
 * yorqinlik, skrinshot, qayta yuklash. Imkon qadar Accessibility gestlari (root talab qilmaydi)
 * ishlatiladi; ular ishlamasa yoki action buni talab qilsa, haqiqiy root (su) buyruqlariga o'tiladi.
 */
class RootControlTool(
    private val context: android.content.Context,
    private val shellManager: RootShellManager,
    private val shizukuManager: ShizukuShellManager
) : AgentTool {

    override val name: String = "root_control"
    override val description: String =
        "Qurilmani past darajada boshqarish: ekranga bosish (tap), surish (swipe), uzoq bosish, " +
            "tugma (back/home/recents/power/volume), matn kiritish, skrinshot olish, Wi-Fi/Bluetooth " +
            "yoqish-o'chirish, ekran yorqinligi, qurilmani qayta yuklash (reboot), root holatini tekshirish."

    override val parametersSchema: Map<String, Any?> = mapOf(
        "type" to "OBJECT",
        "properties" to mapOf(
            "action" to mapOf(
                "type" to "STRING",
                "description" to "'status' (root bormi), 'tap', 'swipe', 'long_press', 'key' (back/home/recents/power/volume_up/volume_down/camera), " +
                    "'type_text', 'screenshot', 'wifi' (on/off), 'bluetooth' (on/off), 'brightness' (0-100), 'reboot'"
            ),
            "x" to mapOf("type" to "INTEGER", "description" to "X koordinatasi (tap/swipe/long_press)"),
            "y" to mapOf("type" to "INTEGER", "description" to "Y koordinatasi (tap/swipe/long_press)"),
            "x2" to mapOf("type" to "INTEGER", "description" to "Surish tugash X nuqtasi (swipe)"),
            "y2" to mapOf("type" to "INTEGER", "description" to "Surish tugash Y nuqtasi (swipe)"),
            "text" to mapOf("type" to "STRING", "description" to "type_text uchun matn"),
            "key" to mapOf("type" to "STRING", "description" to "'key' amali uchun: back, home, recents, power, volume_up, volume_down, camera"),
            "state" to mapOf("type" to "STRING", "description" to "wifi/bluetooth uchun: 'on' yoki 'off'"),
            "value" to mapOf("type" to "INTEGER", "description" to "brightness uchun 0-100")
        ),
        "required" to listOf("action")
    )

    override val requiresConfirmation: Boolean = false

    override fun needsConfirmation(args: Map<String, Any?>): Boolean {
        val action = args["action"]?.toString()?.lowercase()
        return action == "reboot"
    }

    override suspend fun execute(args: Map<String, Any?>): ToolExecutionResult {
        val action = args["action"]?.toString()?.lowercase() ?: "status"
        val x = (args["x"] as? Number)?.toInt()
        val y = (args["y"] as? Number)?.toInt()

        return when (action) {
            "status" -> {
                val hasRoot = shellManager.isRootAvailable()
                val shizukuRunning = shizukuManager.isServiceRunning()
                val shizukuGranted = shizukuManager.hasPermission()
                val hasAccessibility = KotibAccessibilityService.isRunning()
                ToolExecutionResult(
                    isSuccess = true,
                    output = mapOf(
                        "root" to hasRoot,
                        "shizukuRunning" to shizukuRunning,
                        "shizukuGranted" to shizukuGranted,
                        "accessibility" to hasAccessibility
                    ),
                    userSummary = buildString {
                        append(if (hasRoot) "Root (su) huquqi mavjud. " else "Root (su) yo'q. ")
                        append(
                            when {
                                shizukuGranted -> "Shizuku ruxsati berilgan — root bo'lmasa ham to'liq boshqaruv ishlaydi. "
                                shizukuRunning -> "Shizuku ishlamoqda, lekin ruxsat berilmagan ('request_shizuku' bilan so'rang). "
                                else -> "Shizuku ilovasi ishlamayapti (o'rnatilmagan yoki ishga tushirilmagan). "
                            }
                        )
                        append(if (hasAccessibility) "Accessibility xizmati faol." else "Accessibility xizmati o'chiq (Sozlamalar → Maxsus imkoniyatlardan yoqing).")
                    }
                )
            }

            "request_shizuku" -> {
                if (!shizukuManager.isServiceRunning()) {
                    ToolExecutionResult(
                        isSuccess = false,
                        output = mapOf("error" to "Shizuku ishlamayapti"),
                        userSummary = "Shizuku ilovasi topilmadi yoki ishga tushirilmagan. Shizuku ilovasini o'rnating va uni ishga tushiring (root yoki simsiz ADB orqali), so'ng qayta urinib ko'ring."
                    )
                } else if (shizukuManager.hasPermission()) {
                    ToolExecutionResult(true, mapOf("granted" to true), "Shizuku ruxsati allaqachon berilgan.")
                } else {
                    val granted = shizukuManager.requestPermission()
                    ToolExecutionResult(
                        isSuccess = granted,
                        output = mapOf("granted" to granted),
                        userSummary = if (granted) "Shizuku ruxsati berildi. Endi root talab qiladigan amallar ham ishlaydi."
                        else "Shizuku ruxsati berilmadi yoki so'rov vaqti tugadi. Ekranda chiqqan Shizuku oynasida 'Ruxsat berish' ni bosing."
                    )
                }
            }

            "tap" -> {
                if (x == null || y == null) return missingCoords()
                if (KotibAccessibilityService.isRunning() && KotibAccessibilityService.gestureTap(x, y)) {
                    success("Ekrandagi ($x, $y) nuqtasiga bosildi.", mapOf("x" to x, "y" to y, "method" to "accessibility"))
                } else {
                    val r = shellManager.tap(x, y, useRoot = true)
                    rootResult(r, "Ekrandagi ($x, $y) nuqtasiga bosildi.", "Bosib bo'lmadi")
                }
            }

            "long_press" -> {
                if (x == null || y == null) return missingCoords()
                if (KotibAccessibilityService.isRunning() && KotibAccessibilityService.gestureLongPress(x, y)) {
                    success("($x, $y) nuqtasida uzoq bosildi.", mapOf("x" to x, "y" to y, "method" to "accessibility"))
                } else {
                    val r = shellManager.longPress(x, y, useRoot = true)
                    rootResult(r, "($x, $y) nuqtasida uzoq bosildi.", "Uzoq bosib bo'lmadi")
                }
            }

            "swipe" -> {
                val x2 = (args["x2"] as? Number)?.toInt()
                val y2 = (args["y2"] as? Number)?.toInt()
                if (x == null || y == null || x2 == null || y2 == null) return missingCoords()
                if (KotibAccessibilityService.isRunning() && KotibAccessibilityService.gestureSwipe(x, y, x2, y2)) {
                    success("Ekran ($x,$y) dan ($x2,$y2) ga surildi.", mapOf("method" to "accessibility"))
                } else {
                    val r = shellManager.swipe(x, y, x2, y2, useRoot = true)
                    rootResult(r, "Ekran ($x,$y) dan ($x2,$y2) ga surildi.", "Surib bo'lmadi")
                }
            }

            "key" -> {
                val keyName = args["key"]?.toString()?.lowercase() ?: ""
                val code = keyCode(keyName) ?: return ToolExecutionResult(
                    isSuccess = false,
                    output = mapOf("error" to "Noma'lum tugma: $keyName"),
                    userSummary = "Noma'lum tugma: $keyName"
                )
                val handledByAccessibility = when (keyName) {
                    "back" -> KotibAccessibilityService.isRunning() &&
                        KotibAccessibilityService.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                    "home" -> KotibAccessibilityService.isRunning() &&
                        KotibAccessibilityService.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
                    "recents" -> KotibAccessibilityService.isRunning() &&
                        KotibAccessibilityService.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
                    else -> false
                }
                if (handledByAccessibility) {
                    success("'$keyName' tugmasi bosildi.", mapOf("method" to "accessibility"))
                } else {
                    val r = shellManager.pressKeyEvent(code, useRoot = true)
                    rootResult(r, "'$keyName' tugmasi bosildi.", "'$keyName' tugmasini bosib bo'lmadi")
                }
            }

            "type_text" -> {
                val text = args["text"]?.toString().orEmpty()
                if (text.isBlank()) {
                    return ToolExecutionResult(false, mapOf("error" to "Matn ko'rsatilmadi"), "Qanday matn kiritish kerakligini ayting.")
                }
                val isAscii = text.all { it.code < 128 }
                if (KotibAccessibilityService.isRunning() && KotibAccessibilityService.setFocusedText(text)) {
                    success("'$text' matni kiritildi.", mapOf("method" to "accessibility"))
                } else if (isAscii) {
                    val r = shellManager.typeText(text, useRoot = true)
                    rootResult(r, "'$text' matni kiritildi.", "Matn kiritib bo'lmadi")
                } else {
                    ToolExecutionResult(
                        isSuccess = false,
                        output = mapOf("error" to "Fokusdagi maydon topilmadi, Accessibility o'chiq bo'lishi mumkin"),
                        userSummary = "Matn kiritib bo'lmadi: avval kerakli maydonga teging yoki Accessibility xizmatini yoqing (unicode matn uchun u shart)."
                    )
                }
            }

            "screenshot" -> takeScreenshot()

            "wifi", "bluetooth" -> {
                val state = args["state"]?.toString()?.lowercase() ?: "on"
                val enable = state == "on" || state == "yoq" || state == "yoqish"
                val r = if (action == "wifi") shellManager.toggleWifi(enable, useRoot = true)
                else shellManager.toggleBluetooth(enable, useRoot = true)
                rootResult(
                    r,
                    "${if (action == "wifi") "Wi-Fi" else "Bluetooth"} ${if (enable) "yoqildi" else "o'chirildi"}.",
                    "${if (action == "wifi") "Wi-Fi" else "Bluetooth"}ni o'zgartirib bo'lmadi (root kerak)"
                )
            }

            "brightness" -> {
                val value = (args["value"] as? Number)?.toInt()
                if (value == null) return ToolExecutionResult(false, mapOf("error" to "value kerak"), "Yorqinlik qiymatini (0-100) ayting.")
                val target = (value.coerceIn(0, 100) * 255 / 100)
                val r = shellManager.setBrightness(target, useRoot = true)
                rootResult(r, "Ekran yorqinligi $value% ga o'rnatildi.", "Yorqinlikni o'zgartirib bo'lmadi (root kerak)")
            }

            "reboot" -> {
                val r = shellManager.executeCommand("reboot", asRoot = true, timeoutMs = 5000L)
                if (r.isSuccess || r.exitCode == -2) {
                    ToolExecutionResult(true, mapOf("status" to "rebooting"), "Qurilma qayta yuklanmoqda...")
                } else {
                    ToolExecutionResult(false, mapOf("error" to r.error), "Qayta yuklab bo'lmadi (root kerak): ${r.error}")
                }
            }

            else -> ToolExecutionResult(false, mapOf("error" to "Noma'lum amal: $action"), "Noma'lum amal: $action")
        }
    }

    private suspend fun takeScreenshot(): ToolExecutionResult {
        val dir = File(context.getExternalFilesDir(null), "screenshots").apply { mkdirs() }
        val file = File(dir, "shot_${System.currentTimeMillis()}.png")
        val r = shellManager.executeCommand("screencap -p ${shellManager.quote(file.absolutePath)}", asRoot = true, timeoutMs = 10_000L)
        delay(150)
        return if (r.isSuccess && file.exists() && file.length() > 0) {
            ToolExecutionResult(
                isSuccess = true,
                output = mapOf("path" to file.absolutePath, "sizeBytes" to file.length()),
                userSummary = "Skrinshot olindi: ${file.name} (${file.length() / 1024} KB)."
            )
        } else {
            ToolExecutionResult(
                isSuccess = false,
                output = mapOf("error" to r.error),
                userSummary = "Skrinshot olinmadi (root kerak): ${r.error.ifBlank { "noma'lum xato" }}"
            )
        }
    }

    private fun keyCode(key: String): Int? = when (key) {
        "back" -> 4
        "home" -> 3
        "recents", "overview" -> 187
        "power" -> 26
        "volume_up" -> 24
        "volume_down" -> 25
        "camera" -> 27
        "menu" -> 82
        "enter" -> 66
        "delete", "backspace" -> 67
        else -> null
    }

    private fun missingCoords() = ToolExecutionResult(
        isSuccess = false,
        output = mapOf("error" to "Koordinatalar ko'rsatilmadi"),
        userSummary = "X va Y koordinatalarini ko'rsating."
    )

    private fun success(summary: String, extra: Map<String, Any?> = emptyMap()) =
        ToolExecutionResult(true, extra, summary)

    private fun rootResult(r: ShellResult, okMsg: String, failPrefix: String): ToolExecutionResult =
        ToolExecutionResult(
            isSuccess = r.isSuccess,
            output = mapOf("exitCode" to r.exitCode, "error" to r.error),
            userSummary = if (r.isSuccess) okMsg else "$failPrefix (root huquqi kerak bo'lishi mumkin): ${r.error.ifBlank { r.output }}"
        )
}
