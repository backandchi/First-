package com.example.kotib.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Haqiqiy Android Accessibility Service (UI Avtomatlashtirish):
 * Ekranni o'qish, tugmalarni bosish, orqaga/bosh ekranga qaytish,
 * bildirishnomalar panelini tushirish va skrinshot olish imkonini beradi.
 * Root talab qilmaydi!
 */
class KotibAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this

        // Xizmat yoqilgan zahoti bu yerda xato ketsa, butun ilova jarayoni yiqiladi —
        // shuning uchun bu yerda HECH NARSA (hatto kutilmagan holat ham) ilovani urib tushirmasligi kerak.
        try {
            // XML'dagi (accessibility_service_config.xml) sozlamalarni o'chirib tashlamaslik uchun
            // mavjud serviceInfo ustiga qo'shamiz, yangisini yaratib almashtirmaymiz.
            val info = serviceInfo ?: AccessibilityServiceInfo()
            info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            info.flags = info.flags or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            serviceInfo = info
        } catch (e: Exception) {
            // Sozlashda xato bo'lsa ham xizmat ishlayversin (asosiy funksiyalar baribir XML orqali faol)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Kerak bo'lganda ekran o'zgarishlarini kuzatish
    }

    override fun onInterrupt() {
        // Xizmat to'xtatilganda
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
        }
    }

    companion object {
        @Volatile
        var instance: KotibAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null

        fun openAccessibilitySettings(context: Context) {
            try {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (_: Exception) {}
        }

        /**
         * Global harakatlar: Bosh ekran, Orqaga, Bildirishnomalar paneli, Ekranni qulflash
         */
        fun performGlobalAction(action: Int): Boolean {
            val service = instance ?: return false
            return service.performGlobalAction(action)
        }

        /**
         * Ekranda ko'rinib turgan matnlar va tugmalarni o'qib, AI uchun matn xulosasini tuzadi
         */
        fun dumpVisibleScreenTexts(): String {
            val service = instance ?: return "Accessibility xizmati yoqilmagan"
            val rootNode = service.rootInActiveWindow ?: return "Faol ekran oynasi topilmadi"

            val texts = mutableListOf<String>()
            extractTextsRecursive(rootNode, texts)
            return if (texts.isEmpty()) "Ekranda matn topilmadi" else texts.joinToString("\n• ", prefix = "• ")
        }

        private fun extractTextsRecursive(node: AccessibilityNodeInfo?, result: MutableList<String>) {
            if (node == null) return
            val text = node.text?.toString()?.trim()
            val desc = node.contentDescription?.toString()?.trim()
            val isClickable = node.isClickable

            val item = when {
                !text.isNullOrBlank() && !desc.isNullOrBlank() && text != desc -> "$text ($desc)"
                !text.isNullOrBlank() -> text
                !desc.isNullOrBlank() -> desc
                else -> null
            }

            if (!item.isNullOrBlank() && !result.contains(item)) {
                val tag = if (isClickable) "[Tugma] " else ""
                result.add("$tag$item")
            }

            for (i in 0 until node.childCount) {
                extractTextsRecursive(node.getChild(i), result)
            }
        }

        /**
         * Ko'rsatilgan matnli tugmani ekranda topib bosish
         */
        fun clickNodeByText(targetText: String): Boolean {
            val service = instance ?: return false
            val rootNode = service.rootInActiveWindow ?: return false

            val nodes = rootNode.findAccessibilityNodeInfosByText(targetText)
            for (node in nodes) {
                if (node.isClickable) {
                    return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                var parent = node.parent
                while (parent != null) {
                    if (parent.isClickable) {
                        return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }
                    parent = parent.parent
                }
            }
            return false
        }


        // ---------------- Gestlar (root'siz bosish/surish) ----------------

        private suspend fun dispatchPath(path: Path, durationMs: Long): Boolean {
            val service = instance ?: return false
            val done = CompletableDeferred<Boolean>()
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1L)))
                .build()
            val accepted = service.dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        done.complete(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        done.complete(false)
                    }
                },
                null
            )
            if (!accepted) return false
            return withTimeoutOrNull(5_000L) { done.await() } ?: false
        }

        suspend fun gestureTap(x: Int, y: Int): Boolean {
            val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
            return dispatchPath(path, 60L)
        }

        suspend fun gestureLongPress(x: Int, y: Int, durationMs: Long = 800L): Boolean {
            val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
            return dispatchPath(path, durationMs)
        }

        suspend fun gestureSwipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long = 300L): Boolean {
            val path = Path().apply {
                moveTo(x1.toFloat(), y1.toFloat())
                lineTo(x2.toFloat(), y2.toFloat())
            }
            return dispatchPath(path, durationMs)
        }

        /** Fokusdagi matn maydoniga matn yozadi (Unicode/o'zbek harflari bilan ham ishlaydi). */
        fun setFocusedText(text: String, append: Boolean = true): Boolean {
            val service = instance ?: return false
            val rootNode = service.rootInActiveWindow ?: return false
            val node = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false

            val showingHint = Build.VERSION.SDK_INT >= 26 && node.isShowingHintText
            val current = if (append && !showingHint) node.text?.toString() ?: "" else ""
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, current + text)
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }

        /** Hozir ekranda turgan ilovaning paket nomi. */
        fun currentPackage(): String? = instance?.rootInActiveWindow?.packageName?.toString()

        /**
         * Pastga yoki yuqoriga aylantirish (Scroll)
         */
        fun scroll(forward: Boolean): Boolean {
            val service = instance ?: return false
            val rootNode = service.rootInActiveWindow ?: return false

            val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            return rootNode.performAction(action)
        }
    }
}
