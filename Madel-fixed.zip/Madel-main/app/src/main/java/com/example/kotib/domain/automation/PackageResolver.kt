package com.example.kotib.domain.automation

import android.content.Context
import android.content.Intent

/**
 * Ilova nomini ("Telegram", "Kamera") haqiqiy paket nomiga ("org.telegram.messenger") aylantiradi.
 * Taxmin qilmaydi: topilmasa null qaytaradi.
 */
class PackageResolver(private val context: Context) {

    data class AppInfo(val label: String, val packageName: String)

    private val aliases = mapOf(
        "telegram" to "org.telegram.messenger",
        "whatsapp" to "com.whatsapp",
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "instagram" to "com.instagram.android",
        "tiktok" to "com.zhiliaoapp.musically",
        "facebook" to "com.facebook.katana",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps"
    )

    fun isInstalled(packageName: String): Boolean = try {
        context.packageManager.getPackageInfo(packageName, 0)
        true
    } catch (_: Exception) {
        false
    }

    /** Ishga tushirish mumkin bo'lgan (launcher'da ko'rinadigan) barcha ilovalar. */
    @Suppress("DEPRECATION")
    fun launchableApps(): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    /** Nom yoki paket nomi bo'yicha eng mos paketni topadi. */
    fun resolve(nameOrPackage: String): String? {
        val q = nameOrPackage.trim().lowercase()
        if (q.isEmpty()) return null

        aliases[q]?.let { if (isInstalled(it)) return it }
        if (q.contains('.') && isInstalled(q)) return q

        val apps = launchableApps()
        apps.firstOrNull { it.label.lowercase() == q }?.let { return it.packageName }
        apps.firstOrNull { it.label.lowercase().contains(q) }?.let { return it.packageName }
        aliases.entries.firstOrNull { q.contains(it.key) && isInstalled(it.value) }?.let { return it.value }
        return null
    }

    /** Qidiruv so'ziga mos barcha ilovalar. */
    fun search(query: String): List<AppInfo> {
        val q = query.trim().lowercase()
        return launchableApps().filter { it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q) }
    }
}
