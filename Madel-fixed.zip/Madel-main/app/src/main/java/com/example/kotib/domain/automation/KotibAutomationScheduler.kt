package com.example.kotib.domain.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.kotib.data.local.dao.AutomationTaskDao
import com.example.kotib.data.local.entity.AutomationTaskEntity
import com.example.kotib.domain.agent.AgentEngine
import com.example.kotib.service.KotibTaskReceiver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Calendar

/**
 * Rejalashtirilgan vazifalar: har bir vazifa uchun haqiqiy AlarmManager signali o'rnatiladi.
 * Signal kelganda [KotibTaskReceiver] agentni ishga tushiradi.
 */
class KotibAutomationScheduler(
    private val context: Context,
    private val dao: AutomationTaskDao
) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    val allTasks: Flow<List<AutomationTaskEntity>> = dao.getAllTasksFlow()

    private val timeRegex = Regex("^([01]?\\d|2[0-3]):([0-5]\\d)$")

    /** "HH:mm" formatini tekshiradi va keyingi ishga tushish vaqtini (ms) qaytaradi. */
    fun nextTriggerMillis(time: String): Long? {
        val m = timeRegex.matchEntire(time.trim()) ?: return null
        val hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].toInt()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    fun isValidTime(time: String): Boolean = timeRegex.matches(time.trim())

    private fun pendingIntent(taskId: Long): PendingIntent {
        val intent = Intent(context, KotibTaskReceiver::class.java).apply {
            putExtra(KotibTaskReceiver.EXTRA_TASK_ID, taskId)
        }
        return PendingIntent.getBroadcast(
            context,
            taskId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun schedule(task: AutomationTaskEntity) {
        val triggerAt = nextTriggerMillis(task.triggerTime) ?: return
        try {
            // Inexact, lekin Doze rejimida ham ishlaydi va maxsus ruxsat talab qilmaydi
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent(task.id))
        } catch (_: Exception) {
        }
    }

    private fun cancel(taskId: Long) {
        try {
            alarmManager.cancel(pendingIntent(taskId))
        } catch (_: Exception) {
        }
    }

    /** Ilova ishga tushganda va telefon qayta yoqilganda barcha faol vazifalarni qayta o'rnatadi. */
    suspend fun rescheduleAll() = withContext(Dispatchers.IO) {
        dao.getEnabledTasks().forEach { schedule(it) }
    }

    suspend fun initializeDefaultTasksIfEmpty() = withContext(Dispatchers.IO) {
        // Faqat butunlay bo'sh bo'lsa (foydalanuvchi hammasini o'chirib/o'chirib qo'ygan bo'lsa qayta qo'shilmaydi)
        if (dao.getTaskCount() == 0) {
            val defaults = listOf(
                AutomationTaskEntity(
                    title = "Tungi Jimjitlik (Ovozni o'chirish)",
                    triggerTime = "23:00",
                    actionCommand = "Telefon ovozini jimjit rejimga o'tkaz va tungi dam olish rejimini yoq",
                    isEnabled = true,
                    repeatType = AutomationTaskEntity.REPEAT_DAILY
                ),
                AutomationTaskEntity(
                    title = "Tonggi Uyg'onish & Hisobot",
                    triggerTime = "07:30",
                    actionCommand = "Telefon ovozini normal rejimga qaytar va 'Bugun kim nima yozdi?' hisobotini tayyorla",
                    isEnabled = true,
                    repeatType = AutomationTaskEntity.REPEAT_DAILY
                ),
                AutomationTaskEntity(
                    title = "Ish vaqti: Ilovalarni tartibga solish",
                    triggerTime = "09:00",
                    actionCommand = "Ovoz balandligini 70% ga sozla va bugungi vazifalarni ko'rsat",
                    isEnabled = false,
                    repeatType = AutomationTaskEntity.REPEAT_DAILY
                )
            )
            defaults.forEach { dao.insertTask(it) }
        }
        rescheduleAll()
    }

    suspend fun toggleTask(id: Long, enabled: Boolean) = withContext(Dispatchers.IO) {
        dao.setTaskEnabled(id, enabled)
        val task = dao.getTaskById(id)
        if (enabled && task != null) schedule(task) else cancel(id)
    }

    /** Yangi vazifa qo'shadi. Vaqt formati noto'g'ri bo'lsa -1 qaytaradi. */
    suspend fun addTask(title: String, time: String, command: String): Long = withContext(Dispatchers.IO) {
        if (!isValidTime(time)) return@withContext -1L
        val id = dao.insertTask(
            AutomationTaskEntity(
                title = title,
                triggerTime = time.trim(),
                actionCommand = command,
                isEnabled = true
            )
        )
        dao.getTaskById(id)?.let { schedule(it) }
        id
    }

    suspend fun deleteTask(id: Long) = withContext(Dispatchers.IO) {
        cancel(id)
        dao.deleteTaskById(id)
    }

    /**
     * Signal kelganda chaqiriladi: keyingi kunga qayta o'rnatadi va agentni haqiqatan ishga tushiradi.
     */
    suspend fun runTask(taskId: Long, engine: AgentEngine) = withContext(Dispatchers.IO) {
        val task = dao.getTaskById(taskId) ?: return@withContext
        if (!task.isEnabled) return@withContext

        // Avval keyingi kunni o'rnatamiz — agent xato qilsa ham reja yo'qolmasin
        if (task.repeatType == AutomationTaskEntity.REPEAT_DAILY) schedule(task)

        engine.processPrompt("[Rejalashtirilgan vazifa: ${task.title}] ${task.actionCommand}")
        val finished = withTimeoutOrNull(50_000L) { engine.awaitCurrentJob(); true } ?: false

        dao.updateTask(
            task.copy(
                isEnabled = task.repeatType == AutomationTaskEntity.REPEAT_DAILY,
                lastExecutedTimestamp = System.currentTimeMillis(),
                lastExecutionResult = if (finished) "Bajarildi" else "Davom etmoqda (vaqt chegarasi)"
            )
        )
    }
}
