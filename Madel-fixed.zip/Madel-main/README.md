# Aiko — shaxsiy AI agent (Android)

Kotlin + Jetpack Compose ilovasi: Gemini orqali ovoz/matn bilan telefonni boshqaradi, xabarlarni tahlil qiladi.

## APK ni GitHub'da yig'ish

1. Loyihani GitHub'ga yuklang (`main` branch).
2. **Actions** → **Build Android APK** avtomatik ishga tushadi (yoki *Run workflow* tugmasi).
3. Tugagach, run sahifasining pastidagi **Artifacts** bo'limidan `aiko-debug-apk` ni yuklab oling va telefonga o'rnating.
4. `v1.0` kabi teg yuborsangiz (`git tag v1.0 && git push --tags`), APK **Releases** bo'limiga ham chiqadi.

### O'z kalitingiz bilan imzolash (ixtiyoriy)
Repo → Settings → Secrets and variables → Actions: `KEYSTORE_BASE64` (`base64 -w0 my.jks`), `STORE_PASSWORD`, `KEY_PASSWORD`, `KEY_ALIAS` (standart: `upload`).
Secrets bo'lmasa release APK debug kaliti bilan imzolanadi — o'rnatib sinash uchun yetadi, Play Store uchun emas.

## Gemini API kaliti
Kalitni APK ichiga **yozmang** (ochiq repoda APK'ni hamma yuklab oladi). Ilovani ochgach, `Chat` → kalit tugmasi orqali kiriting.

## Lokal build
`gradle wrapper --gradle-version 9.3.1` (bir marta), so'ng `./gradlew assembleDebug`. JDK 17 kerak.
