# Nimalar tuzatildi (Madel → Aiko)

## Build / APK (GitHub'da APK chiqmasligiga sabab bo'ladiganlar)
- `debug.keystore` talab qilinardi, lekin u `.gitignore`da edi → debug build GitHub'da yiqilardi. Endi standart debug kaliti ishlatiladi.
- Release imzosi majburiy `my-upload-key.jks` faylini izlardi. Endi faqat GitHub Secrets berilganda imzolanadi, aks holda debug kaliti bilan.
- Ishlatilmaydigan Firebase (AI, AppCheck *debug*) va `google-services` plagini olib tashlandi (release APK ichida debug provayder bo'lmasligi uchun).
- `compileSdk` 36 (runner'da tayyor platforma). `gradlew` / wrapper jar repoda yo'q edi → workflow Gradle 9.3.1 ni o'zi o'rnatadi.
- `.github/workflows/build-apk.yml` qo'shildi (debug + release APK, `v*` tegida Release).

## Gemini so'rovlari (ilova ishlamasligiga sabab bo'ladiganlar)
- Zaxira model `gemini-3.1-flash-lite-preview` 2026-05-25 da o'chirilgan → `gemini-3.5-flash-lite`.
- Parametrsiz vosita (`check_key_status`) bo'sh `properties` bilan yuborilardi — Gemini butun so'rovni 400 bilan rad etadi. Tuzatildi.
- Gemini 3 `thoughtSignature` qaytarib yuborilmasdi (funksiya chaqiruvida 400). Endi saqlanadi va qaytariladi.
- Parallel funksiya chaqiruvlarida faqat birinchisiga javob berilardi. Endi hammasiga.
- Tarmoq uzilishi "429 limit" deb hisoblanib, kalit bekorga bloklanardi. Endi faqat haqiqiy 429.
- Suhbat tarixi "model" xabari bilan boshlanib qolishi mumkin edi. Tuzatildi.
- API kalit URL (`?key=`) o'rniga `x-goog-api-key` sarlavhasida; loglarda kalit/bot tokeni yashiriladi, release'da log o'chiq.
- Vosita natijalaridagi ro'yxatlar (Map/List) JSON'ga satr sifatida yozilardi. Tuzatildi.

## Xatti-harakat xatolari
- Fondagi (ilova yopiq) xabar uchun qo'ng'iroq Android 10+ da jimgina bloklanardi → full-screen-intent bildirishnomasi qo'shildi.
- Qayta qo'ng'iroq (2 daqiqadan keyin) Activity yopilganda bekor bo'lardi; har bir tinglash yangi collector qo'shib, buyruqlar takror bajarilardi; ekran aylantirilsa qo'ng'iroq qayta boshlanardi; audio rejim `IN_COMMUNICATION`da qolardi. Hammasi tuzatildi.
- Android 11+ da boshqa ilovalarni ko'rish uchun `<queries>` yo'q edi → "ilovalar ro'yxati" va "ilovani ochish" ishlamasdi.
- `POST_NOTIFICATIONS` (Android 13+) va qo'ng'iroq oynasida mikrofon ruxsati so'ralmasdi.
- `ChatViewModel` Activity kontekstini ushlab turardi (xotira oqishi) → applicationContext.
- Emergency Stop vosita bajarilayotganda `CancellationException`ni yutib yuborardi.
- Shell orqali `tap` / `type_text` / `close_app` root bo'lmasa ham "muvaffaqiyatli" deb qaytarardi. Endi haqiqiy natija.
- Obsidian: `../` orqali vault'dan tashqariga fayl yozish mumkin edi.
- `"$label ($match.packageName)"` satr shabloni noto'g'ri edi.
- `allowBackup=false` (API kalitlar Room bazasida ochiq saqlanadi).

## Hali qilinmagan (xabardor bo'ling)
- "Avtomat" bo'limidagi rejalashtirilgan vazifalar (23:00, 07:30...) saqlanadi, lekin hech qanday alarm/worker ularni **ishga tushirmaydi**.
- `requiresConfirmation` barcha vositalarda `false` va hech qayerda tekshirilmaydi (shell, SMS yuborish tasdiqsiz bajariladi).
- `input tap/swipe/text` root yoki ADB'siz ishlamaydi; Accessibility (`click_text`, scroll) ishlaydi.
- Kod kompilyatsiya qilib ko'rilmadi (sandbox'da Android SDK/internet yo'q) — birinchi haqiqiy tekshiruv GitHub Actions'da bo'ladi.

## Root va to'liq boshqaruv (2-bosqich: simulyatsiyalar haqiqiy amalga almashtirildi)

Yangi vositalar qo'shildi va eskilari haqiqiy root/Accessibility amallariga o'tkazildi:

- **`root_control`** (yangi): ekranga bosish/surish/uzoq bosish, tugmalar (back/home/recents/power/volume), matn kiritish, **skrinshot** (`screencap`), Wi-Fi/Bluetooth, ekran yorqinligi, **qayta yuklash (reboot)**. Avval Accessibility gesti (root shart emas) sinaladi, ishlamasa haqiqiy `su` buyrug'iga o'tadi. `reboot` endi chatda tasdiq so'raydi.
- **`manage_files`** (yangi): fayl/papkalarni ro'yxatlash, o'qish, yozish, o'chirish, papka yaratish — ilova papkasida ruxsatsiz, umumiy xotirada (masalan `/storage/emulated/0/Download/...`) root bilan ishlaydi. O'chirish tasdiq so'raydi.
- **`manage_packages`** (yangi): o'rnatilgan ilovalarni ro'yxatlash/qidirish, to'xtatish, keshni tozalash, **butunlay o'chirish (uninstall)**, ruxsat berish (`pm grant`) — `pm` orqali haqiqiy root buyruqlari. O'chirish/tozalash tasdiq so'raydi.
- **`control_installed_apps`**: endi ilova nomlarini `PackageResolver` orqali barcha o'rnatilgan ilovalar ro'yxatidan topadi (avval faqat 6 ta ilova qattiq yozilgan edi). Telegram/WhatsApp/SMS'ga xabar yuborishda qabul qiluvchini `ContactResolver` orqali **haqiqiy telefon kontaktlaridan** qidiradi (avval raqam hech qachon topilmasa ham "xabar yuborildi" deb yolg'on aytardi); endi kontakt topilmasa yoki bir nechta mos kelsa, aniq xato/tanlov qaytaradi. Xabar matni Accessibility orqali haqiqatan maydonga yoziladi va "Yuborish" bosiladi.
- **Tasdiqlash tizimi**: xavfli amallar (reboot, fayl/ilova o'chirish) endi chatda haqiqiy tasdiq oynasini ochadi va foydalanuvchi "Ruxsat berish" bosmaguncha bajarilmaydi (45 soniya kutadi, javob kelmasa bekor qilinadi). Avval `requiresConfirmation` hech qayerda ishlatilmas edi.
- `RootShellManager` qayta yozildi: `su -c id` orqali haqiqiy root tekshiruvi (natijasi keshlanadi), har bir buyruq uchun haqiqiy timeout (jarayon osilib qolsa majburan o'ldiriladi), argumentlar shell-safe tarzda qo'shtirnoqlanadi (`'...'`).
- **Rejalashtirilgan vazifalar endi haqiqatan ishga tushadi**: har bir vazifa uchun `AlarmManager` signali o'rnatiladi (`KotibTaskReceiver`), signal kelganda agent chaqiriladi va natija saqlanadi. Telefon qayta yoqilganda (`KotibBootReceiver`) barcha signallar tiklanadi. Vaqt formati endi tekshiriladi (HH:mm).
- Sozlamalar ekraniga **Root holati** kartasi qo'shildi (mavjud/yo'qligini ko'rsatadi).
- Manifestga `READ_CONTACTS` (kontakt qidirish) va `RECEIVE_BOOT_COMPLETED` (rejalarni tiklash) ruxsatlari qo'shildi.

### Muhim eslatma
Root funksiyalari faqat **root qilingan (rooted)** qurilmada ishlaydi (Magisk/KernelSU va h.k.). Root bo'lmagan oddiy telefonda `root_control`, fayl/ilova o'chirish kabi amallar xato qaytaradi, lekin ekranni o'qish, tugma bosish va xabar yozish **Accessibility Service** orqali root'siz ham ishlaydi (avvalgidek).

### Hali ham qo'lda tekshirish kerak bo'lgan narsalar
- `pm uninstall` tizim ilovalarini (preinstalled) o'chira olmasligi mumkin, hatto root bilan ham (OEM cheklovi).
- `input text` faqat ASCII uchun ishonchli; o'zbek lotin alifbosidagi maxsus belgilar uchun Accessibility orqali yozish ustunlik qiladi (shu sabab avval shu usul sinaladi).
- Kod kompilyatsiya qilib ko'rilmadi — birinchi tekshiruv GitHub Actions'da.
